public class Autor implements Comparable<Autor>{
    public String nazwisko, imie;

    public Autor(String nazwisko, String imie){
        this.nazwisko = nazwisko;
        this.imie = imie;
    }

    public String toString(){
        return nazwisko + " " + imie;
    }

    @Override
    public int compareTo(Autor a) {
        if(a.nazwisko.compareTo(this.nazwisko) == 0)
            return a.imie.compareTo(this.imie);
        return a.nazwisko.compareTo(this.nazwisko);
    }
}
