import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

public class Main1 {
    ArrayList<Ksiazka> ksiazki;

    public Main1(){
        ksiazki = new ArrayList<Ksiazka>();
    }

    public void wpisz(Ksiazka k){
        ksiazki.add(k);
    }

    public void wyswietlTyt(){
        System.out.println("wszystkie ksiazki alfabetycznie wg tytulow: ");
        Collections.sort(ksiazki, new CompareTytul());
        for(Ksiazka k : ksiazki){
            System.out.println(k.toString()); //dodac formatowanie
        }
        System.out.println();
    }

    public void wyswietlTytSet(){
        System.out.println("wszystkie ksiazki alfabetycznie wg tytulow bez powtorzen: ");
        TreeSet<Ksiazka> set = new TreeSet<Ksiazka>(new CompareTytul());
        for(Ksiazka k : ksiazki){
            set.add(k);
        }
        Iterator<Ksiazka> itr = set.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());
        }
        System.out.println();

    }

    public void wyswietlAut(){
        System.out.println("wszystkie ksiazki alfabetycznie wg autorow bez powtorzen: ");
        Collections.sort(ksiazki, new CompareAutor());
        for(int i = 0; i < ksiazki.size(); i++){
            int pom = 0;
            if(i != 0)  pom = ksiazki.get(i).compareTo(ksiazki.get(i - 1));


            if(i == 0)
                System.out.println(ksiazki.get(i).toString());
            else if(pom != 0){
                System.out.println(ksiazki.get(i).toString());
            }
        }
        System.out.println();
    }

    public void wyswietlWsk(Autor autor){
        System.out.println("wyświetlenie alfabetyczne wg tytułów książek wskazanego autora (bez powtórzeń): ");
        ArrayList<Ksiazka> pom = new ArrayList<Ksiazka>();

        for(Ksiazka k : ksiazki){
            if(k.autor.compareTo(autor) == 0){
                pom.add(k);
            }
        }
        Collections.sort(pom, new CompareTytul());

        for(int i = 0; i < pom.size(); i++){
            int pom2 = 0;
            if(i != 0)  pom2 = pom.get(i).compareTo(pom.get(i - 1));


            if(i == 0)
                System.out.println(pom.get(i).toString());
            else if(pom2 != 0){
                System.out.println(pom.get(i).toString());
            }
        }
        System.out.println();
    }

    public void autorzy(){
        System.out.println("wyświetlenie alfabetyczne wszystkich autorów książek (bez powtórzeń): ");
        ArrayList<Autor> autorzy = new ArrayList<Autor>();

        for(Ksiazka k : ksiazki){
            boolean h = false;
            for(Autor a : autorzy){
                if(k.autor == a) h = true;
            }
            if(h == false) autorzy.add(k.autor);
        }
        Collections.sort(autorzy);
        for(Autor a : autorzy){
            System.out.println(a.toString());
        }
        System.out.println();
    }

    public void usun(Autor autor){
        System.out.println("usunięcie wszystkich książek wskazanego autora: ");

        for(int i = 0; i < ksiazki.size(); i++){
            if(ksiazki.get(i).autor == autor) {
                ksiazki.remove(ksiazki.get(i));
                i--;
            }
        }

        for(Ksiazka k : ksiazki){
            System.out.println(k.toString());
        }
        System.out.println();
    }

    public void wys(String wyd){
        System.out.println("wyświetlenie alfabetyczne wg tytułów książek wskazanego autora (bez powtórzeń): ");
        ArrayList<Ksiazka> pom = new ArrayList<Ksiazka>();

        for(Ksiazka k : ksiazki){
            if(k.wydawnictwo.compareTo(wyd) == 0){
                pom.add(k);
            }
        }
        Collections.sort(pom, new CompareRok());
        for(Ksiazka k : pom) System.out.println(k.toString());
        System.out.println();
    }

    public static void main(String[] args) {
        Main1 start = new Main1();

        Autor mickiewicz = new Autor("Mickiewicz", "Adam");

        start.wpisz(new Ksiazka(mickiewicz, "Pan Tadeusz", "PWN", 1900));
        start.wpisz(new Ksiazka(mickiewicz, "Pan Tadeusz", "PWN", 1900));
        start.wpisz(new Ksiazka(mickiewicz, "Dziady", "PWN", 1900));
        start.wpisz(new Ksiazka(new Autor("Z", "A"), "Tadeusz", "312PWN", 111900));

        start.wyswietlTyt();
        start.wyswietlTytSet();
        start.wyswietlAut();
        start.wyswietlWsk(mickiewicz);
        start.autorzy();
        start.wys("PWN");
        start.usun(mickiewicz);
    }
}
