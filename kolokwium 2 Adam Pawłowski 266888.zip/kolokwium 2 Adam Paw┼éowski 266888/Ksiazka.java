import java.util.Comparator;

public class Ksiazka implements Comparable<Ksiazka> {
    public Autor autor;
    public String tytul, wydawnictwo;
    int rok_wydania;

    public Ksiazka(Autor autor, String tytul, String wydawnictwo, int rok_wydania){
        this.autor = autor;
        this.tytul = tytul;
        this.wydawnictwo = wydawnictwo;
        this.rok_wydania = rok_wydania;
    }

    @Override
    public int compareTo(Ksiazka k) {
        return k.tytul.compareTo(this.tytul);
    }

    @Override
    public String toString() {
        return autor.toString() + " " + tytul + " " + wydawnictwo + " " + rok_wydania;
    }
}
