import java.util.Comparator;

public class CompareTytul implements Comparator<Ksiazka> {
    @Override
    public int compare(Ksiazka k1, Ksiazka k2) {
        return k1.tytul.compareTo(k2.tytul);
    }
}
