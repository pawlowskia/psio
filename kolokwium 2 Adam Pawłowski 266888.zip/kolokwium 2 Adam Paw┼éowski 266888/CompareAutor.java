import java.util.Comparator;

public class CompareAutor implements Comparator<Ksiazka> {
    @Override
    public int compare(Ksiazka k1, Ksiazka k2) {
        if(k1.autor.nazwisko.compareTo(k2.autor.nazwisko) == 0)
            return k1.autor.imie.compareTo(k2.autor.imie);
        return k1.autor.nazwisko.compareTo(k2.autor.nazwisko);
    }
}
