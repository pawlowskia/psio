import java.util.Comparator;

public class CompareRok implements Comparator<Ksiazka> {
    @Override
    public int compare(Ksiazka k1, Ksiazka k2) {
        if(k1.rok_wydania == k2.rok_wydania) return 0;
        else if(k1.rok_wydania < k2.rok_wydania) return 1;
        else return -1;
    }
}
