public class klasa1 {
}
