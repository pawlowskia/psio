public class Fork implements Weapon {
    public void presentWeapon() {
        System.out.print("presenting a fork.\n");
    }

    public int damage() {
        return 3;
    }
}
