public interface Armor {
    public int armorValue();
}
