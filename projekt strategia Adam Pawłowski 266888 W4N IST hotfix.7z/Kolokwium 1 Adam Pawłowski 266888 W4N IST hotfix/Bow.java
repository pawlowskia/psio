public class Bow implements Weapon {
    public void presentWeapon() {
        System.out.print("presenting a bow.\n");
    }

    public int damage() {
        return 7;
    }
}
