public class LightArmor implements Armor {
    public int armorValue() {
        return 3;
    }
}
