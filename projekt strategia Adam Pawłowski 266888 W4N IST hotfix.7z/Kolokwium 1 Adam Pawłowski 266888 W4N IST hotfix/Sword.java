public class Sword implements Weapon {
    public void presentWeapon() {
        System.out.print("presenting a sword.\n");
    }

    public int damage() {
        return 10;
    }
}
