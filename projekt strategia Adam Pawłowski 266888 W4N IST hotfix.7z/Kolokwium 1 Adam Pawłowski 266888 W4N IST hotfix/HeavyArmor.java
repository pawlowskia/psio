public class HeavyArmor implements Armor {
    public int armorValue() {
        return 5;
    }
}
