public interface Weapon {
    public void presentWeapon();

    public int damage();
}
